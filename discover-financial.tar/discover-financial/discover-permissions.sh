#!/usr/bin/env bash

# This sets up Discover DCOS Group Permissions

clear
#
read -r -p "Do you need to log into DCOS to update your access token [y/N] " response
if [[ "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]
then
    dcos auth login
fi


#
read -r -p "Do you need to install the DCOS Security Extensions [y/N] " response
if [[ "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]
then
	# Install the Security Subcommand into the CLI
	dcos package install --yes --cli dcos-enterprise-cli
fi

read -r -p "Add permission groups for Discover ACE Data Center [y/N] " response
if [[ "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]
then
#
# Groups
#
   dcos security org groups create full-access
   dcos security org groups create read-only-access
   dcos security org groups create management-do-nothing-access
   dcos security org groups create dev-operator
#
# Permission ACLs - FULL-ACCESS
#
   dcos security org groups grant full-access dcos:adminrouter:ops:mesos full
   dcos security org groups grant full-access dcos:adminrouter:ops:slave full
   # Marathon
   dcos security org groups grant full-access dcos:adminrouter:service:marathon full
   dcos security org groups grant full-access dcos:adminrouter:service:marathon-dev full
   # Services
   dcos security org groups grant full-access dcos:service:marathon:marathon-user:services:/ full
   dcos security org groups grant full-access dcos:service:marathon:marathon:services:/ full
   # Network Tab
   dcos security org groups grant full-access dcos:adminrouter:ops:networking full
   dcos security org groups grant full-access dcos:adminrouter:ops:mesos full
   # Secrets Tab
   dcos security org groups grant full-access dcos:adminrouter:secrets full
   # COMPONENTS
   dcos security org groups grant full-access dcos:adminrouter:ops:historyservice full
   dcos security org groups grant full-access dcos:adminrouter:ops:system-health full
   # Setting and Organization
   dcos security org groups grant full-access dcos:adminrouter:acs full
#
# Dev - Operator
#
   dcos security org groups grant dev-operator dcos:adminrouter:ops:mesos full
   dcos security org groups grant dev-operator dcos:adminrouter:ops:slave full
   dcos security org groups grant dev-operator dcos:adminrouter:service:marathon full
   dcos security org groups grant dev-operator dcos:service:marathon:marathon-user:services:/secure full
   dcos security org groups grant dev-operator dcos:service:marathon:marathon:services:/secure full
   dcos security org groups grant dev-operator dcos:mesos:agent:executor:app_id:/secure full 
   dcos security org groups grant dev-operator dcos:mesos:agent:framework:role:slave_public full
   dcos security org groups grant dev-operator dcos:mesos:agent:sandbox:app_id:/secure full
   dcos security org groups grant dev-operator dcos:mesos:agent:task:app_id:/secure full
   dcos security org groups grant dev-operator dcos:mesos:master:executor:app_id:/secure full
   dcos security org groups grant dev-operator dcos:mesos:master:framework:role:slave_public full
   dcos security org groups grant dev-operator dcos:mesos:master:task:app_id:/secure full
   dcos security org groups grant dev-operator dcos:mesos:agent:log read
#
# Permission ACLs - Read-Only
#
   dcos security org groups grant read-only-access	dcos:adminrouter:ops:mesos full 
   dcos security org groups grant read-only-access	dcos:adminrouter:ops:slave full 
   dcos security org groups grant read-only-access	dcos:adminrouter:service:marathon full 
   dcos security org groups grant read-only-access	dcos:mesos:agent:executor:app_id:/ read 
   dcos security org groups grant read-only-access	dcos:mesos:agent:framework:role full 
   dcos security org groups grant read-only-access	dcos:mesos:agent:sandbox:app_id:/ read 
   dcos security org groups grant read-only-access	dcos:mesos:agent:task:app_id:/ read 
   dcos security org groups grant read-only-access	dcos:mesos:master:executor:app_id:/ read 
   dcos security org groups grant read-only-access	dcos:mesos:master:framework:role full 
   dcos security org groups grant read-only-access	dcos:mesos:master:task:app_id:/ read 
   dcos security org groups grant read-only-access	dcos:service:marathon:marathon:services:/ read 

#
# Permission ACLs - Management - Do Nothing
#
   dcos security org groups grant management-do-nothing-access dcos:adminrouter:ops:mesos full
   dcos security org groups grant management-do-nothing-access dcos:adminrouter:ops:slave full
   dcos security org groups grant management-do-nothing-access dcos:adminrouter:ops:system-health  read
   dcos security org groups grant management-do-nothing-access dcos:mesos:agent:executor:app_id:/secure read
   dcos security org groups grant management-do-nothing-access dcos:mesos:agent:framework:role full
   dcos security org groups grant management-do-nothing-access dcos:mesos:agent:sandbox:app_id:/secure read
   dcos security org groups grant management-do-nothing-access dcos:mesos:agent:task:app_id:/secure read
   dcos security org groups grant management-do-nothing-access dcos:mesos:master:executor:app_id:/secure read
   dcos security org groups grant management-do-nothing-access dcos:mesos:master:framework:role full
   dcos security org groups grant management-do-nothing-access dcos:mesos:master:task:app_id:/secure read
   # Marathon
   dcos security org groups grant management-do-nothing-access dcos:adminrouter:service:marathon read
   dcos security org groups grant management-do-nothing-access dcos:adminrouter:service:marathon-dev read
   # Services
   dcos security org groups grant management-do-nothing-access dcos:service:marathon:marathon-user:services:/ read
   # Network Tab
   dcos security org groups grant management-do-nothing-access dcos:adminrouter:ops:networking read
   dcos security org groups grant management-do-nothing-access dcos:adminrouter:ops:mesos read
   # Secrets Tab
   dcos security org groups grant management-do-nothing-access dcos:adminrouter:secrets read

fi

