#! /bin/bash

# This sets up Discover DCOS Groups

clear
#
read -r -p "Do you need to log into DCOS to update your access token [y/N] " response
if [[ "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]
then
    dcos auth login
fi


read -r -p "Add groups for Discover Data Center [y/N] " response
if [[ "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]
then
    echo '{"id":"secure"}' > group.json
    dcos marathon group add group.json

    echo '{"id":"non-secure"}' > group.json
    dcos marathon group add group.json

    rm -f group.json
fi

